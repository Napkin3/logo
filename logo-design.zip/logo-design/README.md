# Logo design

A Pen created on CodePen.io. Original URL: [https://codepen.io/napkin3/pen/yLELowR](https://codepen.io/napkin3/pen/yLELowR).

